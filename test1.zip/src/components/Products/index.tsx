import React, { useState } from 'react';
import Filters from './Filters';
import FundList from './FundList';
import { Fund, Filter } from './types';
import { initialFunds, initialFilters } from './data';

interface ProductsProps {
  onFundSelect: (fundId: string) => void;
}

export default function Products({ onFundSelect }: ProductsProps) {
  const [funds, setFunds] = useState<Fund[]>(initialFunds);
  const [activeFilters, setActiveFilters] = useState<Filter[]>(initialFilters);
  const [sortBy, setSortBy] = useState<string>('returns');

  const handleFilterChange = (filterId: string) => {
    setActiveFilters(filters =>
      filters.map(f => 
        f.id === filterId ? { ...f, selected: !f.selected } : f
      )
    );
  };

  const handleSortChange = (value: string) => {
    setSortBy(value);
    setFunds(prev => {
      const sorted = [...prev].sort((a, b) => {
        if (value === 'returns') return b.returns - a.returns;
        if (value === 'rating') return b.rating - a.rating;
        return 0;
      });
      return sorted;
    });
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="flex flex-col lg:flex-row gap-8">
        <aside className="lg:w-64">
          <Filters filters={activeFilters} onFilterChange={handleFilterChange} />
        </aside>
        <main className="flex-1">
          <FundList 
            funds={funds} 
            sortBy={sortBy} 
            onSortChange={handleSortChange}
            onFundSelect={onFundSelect}
          />
        </main>
      </div>
    </div>
  );
}